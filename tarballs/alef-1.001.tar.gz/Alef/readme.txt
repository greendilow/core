alef.hagilda.com

אָ‏לֵף הוא גופן רשת דו־לשוני פתוח
==========================
אלף נולד למסך ועוצב לפיקסל מתוך מוטיבציה להרחיב את מנעד הגופנים הקיימים בעברית ברשת, ובעיקר להוות אלטרנטיבה אמיתית לברירת המחדל - "אריאל".

Alef is an open source bilingual webfont
========================================
Alef was born to the screen and designed to the pixel in an attempt to extend the pallet of Hebrew fonts available for web design and especially to challenge the only default — "Arial".

In this folder:

Alef
┃
┣━ OFL-license.txt		// the open font license
┣━ *.txt				// True Type files, can be used beyond the web
┗━ readme.txt			// a bit about what's in the package

